package com.infodart.salman.Pojo_Classes.Model_ForgotPassword;

public class Pojo_forgot_password {

    String email;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }
}
