package com.infodart.salman.Pojo_Classes.Model_Login;

public class Pojo_login {

    String username;
    String password;

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
}
