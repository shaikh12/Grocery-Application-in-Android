package com.infodart.salman.Pojo_Classes.Model_HomePage;

public class Productconfig {

    String image_path;
    String product_id;
    String lotteryproduct;


    public String getLotteryproduct() {
        return lotteryproduct;
    }

    public Productconfig setLotteryproduct(String lotteryproduct) {
        this.lotteryproduct = lotteryproduct;
        return this;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;

    }

    public String getImage_path() {
        return image_path;
    }

    public Productconfig setImage_path(String image_path) {
        this.image_path = image_path;
        return this;
    }
}
