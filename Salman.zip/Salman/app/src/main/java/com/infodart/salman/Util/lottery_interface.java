package com.infodart.salman.Util;

public interface lottery_interface {
    void onclick(int position);
}
