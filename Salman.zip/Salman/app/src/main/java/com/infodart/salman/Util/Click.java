package com.infodart.salman.Util;

public interface Click {
     void Onclick(String v, int position);

}
