package com.infodart.salman.Pojo_Classes.Model_HomePage;

public class ParentDataHomeResponse extends BaseResponse {

  public HomeAccess data;

    public HomeAccess getData() {
        return data;
    }

    public void setData(HomeAccess data) {
        this.data = data;
    }
}
