package com.infodart.salman.Util;

import android.view.View;

public interface RecyclerViewClickListener {
     void recyclerViewListClicked(View v, int position);
}
