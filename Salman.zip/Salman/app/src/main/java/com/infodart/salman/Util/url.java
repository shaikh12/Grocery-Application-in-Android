package com.infodart.salman.Util;

public interface url {

    //image url in the home fragment
    String img_URL = "http://14.141.50.214:9031/grocery-dev/admin/public/files/images/supermarkets/";

    //category image in the cart_category activity
    String cart_img_URL = "http://14.141.50.214:9031/grocery-dev/admin/public/files/images/category/";

    // cart products image under pulses fragment
    String PRODUCTBASE="http://14.141.50.214:9031/grocery-dev/admin/public/files/images/products/";


    String PRIVACY_POLICY="http://14.141.50.214:9031/grocery-test/public/privacy";

    String FAQ_LINK="http://14.141.50.214:9031/grocery-test/public/faq";

    String TERMS_CONDITIONS="http://14.141.50.214:9031/grocery-test/public/terms-and-conditions";

    String ABOUTUS_LINK="http://14.141.50.214:9031/grocery-test/public/about-us";

    String CONTACT_US="http://14.141.50.214:9031/grocery-test/public/contact-us";

}
