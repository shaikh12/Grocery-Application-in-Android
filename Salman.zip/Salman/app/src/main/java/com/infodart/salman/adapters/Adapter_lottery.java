package com.infodart.salman.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.infodart.salman.Pojo_Classes.HomePageNew.Product;
import com.infodart.salman.Pojo_Classes.Model_HomePage.LotteryDrawResponse;
import com.infodart.salman.R;
import com.infodart.salman.Util.image_glide;
import com.infodart.salman.Util.url;
import com.infodart.salman.activity.City_cart_Detailed;
import com.infodart.salman.fragments.HomeFragment;

import java.util.List;

public class Adapter_lottery extends RecyclerView.Adapter<Adapter_lottery.MyHolder> {

    private lottery_interface lottery_interface;
    public Context context;
    List<LotteryDrawResponse> arraylist_product;


    public Adapter_lottery(Context context ,lottery_interface lottery_interface,List<LotteryDrawResponse> arraylist) {
        this.context = context;
        this.lottery_interface = lottery_interface;
        this.arraylist_product = arraylist;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.custom_list,parent,false);
        Adapter_lottery.MyHolder myHolder = new MyHolder(view,lottery_interface);
        return myHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        holder.title.setText(arraylist_product.get(position).getName());
        image_glide.loadimg(context,holder.image, url.PRODUCTBASE,
                arraylist_product.get(position).getProductconfig().get(0).getImage_path());
    }

    @Override
    public int getItemCount() {


        if (arraylist_product.size()== 3){
            return 3;

        }else if (arraylist_product.size() >3 ){
            return 3;

        }else if (arraylist_product.size() <3 ){
            return arraylist_product.size();
        }
        else
            return arraylist_product.size();
    }

    public interface lottery_interface {
        void onclick(int position);
    }

    public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView title;
        ImageView image;

        lottery_interface lottery_interface;

        public MyHolder(@NonNull View itemView,lottery_interface lottery_interface) {
            super(itemView);

            title = itemView.findViewById(R.id.textview_superMarket);
            image = itemView.findViewById(R.id.image_cardview);
            this.lottery_interface = lottery_interface;

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(context, City_cart_Detailed.class);
                    intent.putExtra("id", arraylist_product.get(getAdapterPosition()).getProductconfig().get(0).getProduct_id());
                    context.startActivity(intent);
                }
            });
        }

        @Override
        public void onClick(View v) {
            lottery_interface.onclick(getAdapterPosition());
        }
    }

}
