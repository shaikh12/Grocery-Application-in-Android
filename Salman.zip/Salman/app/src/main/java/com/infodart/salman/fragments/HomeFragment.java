package com.infodart.salman.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.infodart.salman.Pojo_Classes.HomePageNew.Product;
import com.infodart.salman.Pojo_Classes.Model_HomePage.ChildHomeResponse;
import com.infodart.salman.Pojo_Classes.Model_HomePage.LotteryDrawResponse;
import com.infodart.salman.Pojo_Classes.Model_HomePage.ParentDataHomeResponse;
import com.infodart.salman.Util.SharePrefrence;
import com.infodart.salman.activity.Location_Activity;
import com.infodart.salman.R;
import com.infodart.salman.adapters.Adapter_lottery;
import com.infodart.salman.adapters.ViewPagerAdapter;
import com.infodart.salman.activity.Cart_Category;
import com.infodart.salman.adapters.AdapterRecyclerGrid;
import com.infodart.salman.controllers.Api_Interface;
import com.infodart.salman.controllers.Api_Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment implements
        AdapterRecyclerGrid.OnNoteListener, Adapter_lottery.lottery_interface {

    // for displaying Image through viewpager and dots to show position
    private ViewPager viewPager;
    private LinearLayout sliderDotspanel;
    private int dotsCount;
    private ImageView[] dots;
    private TextView textview_location;
    Handler handler;
    Runnable runnable;
    private TextView txt_showlottery;

    RecyclerView recyclerView,recyclerView_lottery;
    RecyclerView.LayoutManager layoutManager;

    AdapterRecyclerGrid adapterRecyclerGrid;
    Adapter_lottery adapter_lottery;
    List<ChildHomeResponse> arrayList = new ArrayList<>();
    List<LotteryDrawResponse> arrayList_Products = new ArrayList<com.infodart.salman.Pojo_Classes.Model_HomePage.LotteryDrawResponse>();
    private Api_Interface api_interface;

    private ImageView imageView;
    static int a;

    int currentPage = 0;
    Timer timer;
    final long DELAY_MS = 300;//delay in milliseconds before task is to be executed
    final long PERIOD_MS = 2700;// time in milliseconds between successive task executions.

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onPause() {
        super.onPause();
        timer.cancel();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        String latitude = "25.151046";
        String longitude = "55.244308";

        txt_showlottery = view.findViewById(R.id.textview_Lottery_seeAll);
        txt_showlottery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "hii", Toast.LENGTH_SHORT).show();
            }
        });


        recyclerView = view.findViewById(R.id.recycler_view);
        recyclerView_lottery = view.findViewById(R.id.recycler_view_lottery);

        api_interface = Api_Utils.getAPIService();
        Call<ParentDataHomeResponse> homePageCall = api_interface.homeData("Bearer " +
                SharePrefrence.getToken(getActivity()), latitude, longitude);

        ProgressDialog();

        // API CALL gethome..................
        homePageCall.enqueue(new Callback<ParentDataHomeResponse>() {
            @Override
            public void onResponse(Call<ParentDataHomeResponse> call, Response<ParentDataHomeResponse> response) {

                Log.e("Tag", "response:" + response.message());
                arrayList = response.body().getData().getList();

                if (response.body().code.equals("403"))
                    Toast.makeText(getContext(), "There is no supermarket available for this location", Toast.LENGTH_SHORT).show();
                else {
                    supermarketlist(arrayList);
                }

                // FOR LOTTERY......................................
                for(int i =0 ; i<response.body().getData().getList().size();i++) {
                    for(int j = 0; j<response.body().getData().getList().get(i).getProducts().size(); j++) {

                        arrayList_Products.add(response.body().getData().getList().get(i).getProducts().get(j));
                        lottery(arrayList_Products);
                    }
                 }
            }
            @Override
            public void onFailure(Call<ParentDataHomeResponse> call, Throwable t) {
                Log.e("Tag", "failure:" + t.toString());
            }
        });

       // lottery(list);

        // this snippet is for supermarket view using RecyclerView,LayoutManager
        imageView = view.findViewById(R.id.image_cardview);

        //casting of IDs
        sliderDotspanel = view.findViewById(R.id.SliderDots);

        //----------- CODE FOR DIRECTING THE LOCATION------------------------
        textview_location = view.findViewById(R.id.textview_location);
        textview_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Location_Activity.class);
                startActivity(intent);
            }
        });

        //--------code for dots on the image to switch the images----------------
        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getActivity());
        viewPager = view.findViewById(R.id.viewpager_home);
        viewPager.setAdapter(viewPagerAdapter);
        dotsCount = viewPagerAdapter.getCount();
        dots = new ImageView[dotsCount];

        /*After setting the adapter use the timer */
        handler = new Handler();
        runnable = new Runnable() {
            public void run() {
                if (currentPage == dotsCount) {
                    currentPage = 0;
                }
                viewPager.setCurrentItem(currentPage++, true);
            }
        };
        timer = new Timer(); // This will create a new Thread
        timer.schedule(new TimerTask() { // task to be scheduled
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, DELAY_MS, PERIOD_MS);


        for (int i = 0; i < dotsCount; i++) {

            dots[i] = new ImageView(getActivity());
            dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.non_active_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout
                    .LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);
            sliderDotspanel.addView(dots[i], params);
        }

        dots[0].setImageDrawable(ContextCompat.getDrawable(getActivity(),R.drawable.active_dot));

        //THis code is for sliding the dots on the Image
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset,
                                       int positionOffsetPixels) {
            }
            @Override
            public void onPageSelected(int position) {
                for (int i = 0; i < dotsCount; i++) {
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getActivity(), R.drawable.non_active_dot));
                }
                dots[position].setImageDrawable(ContextCompat.getDrawable(getActivity(),
                                R.drawable.active_dot));
            }
            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        return view;
        //--------------Code for dots ends -----------------------------------
    }
    // For SuperMarket Cart........ method of interface
    @Override
    public void onClick(int position) {
        Intent intent = new Intent(getContext(), Cart_Category.class);
        intent.putExtra("position", arrayList.get(position).getId());
        intent.putExtra("SUPERMATKETNAME",arrayList.get(position).getName());
        startActivity(intent);
    }

    //For supermarket...setting the adapter
    public void supermarketlist(List<ChildHomeResponse> list) {
        layoutManager = new GridLayoutManager(getContext(), 3);
        recyclerView.setLayoutManager(layoutManager);
        //This is a class adapterRecyclerGrid
        adapterRecyclerGrid = new AdapterRecyclerGrid(getContext(), list,
                this);
        recyclerView.setAdapter(adapterRecyclerGrid);

    }

    //For Lottery...setting the adapter
    public void lottery(List<LotteryDrawResponse> arrayList_Products){

        layoutManager = new GridLayoutManager(getContext(),3);
        recyclerView_lottery.setLayoutManager(layoutManager);
        adapter_lottery = new Adapter_lottery(getContext(),this,arrayList_Products);
        recyclerView_lottery.setAdapter(adapter_lottery);


    }

    private void ProgressDialog() {

        int progressStatus = 0;
        final Handler handler = new Handler();

        final ProgressDialog pd = new ProgressDialog(getActivity());

        // Set progress dialog style spinner
        pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);

        // Set the progress dialog message
        pd.setMessage("Loading...");

        // Set the progress dialog background color
        pd.getWindow().setBackgroundDrawable(new ColorDrawable
                (Color.parseColor("#FFD4D9D0")));

        pd.setIndeterminate(false);

        // Finally, show the progress dialog
        pd.show();

        // Set the progress status zero on each button Click
        progressStatus = 0;

        // Start the lengthy operation in a background thread
        final int[] finalProgressStatus = {progressStatus};
        new Thread(new Runnable() {
            @Override
            public void run() {
                while (finalProgressStatus[0] < 100) {
                    // Update the progress status
                    finalProgressStatus[0] += 1;

                    // Try to sleep the thread for 20 milliseconds
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    // Update the progress bar
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            // Update the progress status
                            pd.setProgress(finalProgressStatus[0]);
                            // If task execution completed
                            if (finalProgressStatus[0] == 100) {
                                // Dismiss/hide the progress dialog
                                pd.dismiss();
                            }
                        }
                    });
                }
            }
        }).start(); // Start the operation
    }

    //For Lottery........ method of interface
    @Override
    public void onclick(int position) {
        Toast.makeText(getContext(), "Rewards received", Toast.LENGTH_SHORT).show();
    }
}

